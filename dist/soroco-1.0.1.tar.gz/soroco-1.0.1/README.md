# Sort Role Coach aka SOROCO

It is a sorting library, which can be used to test the working efficiency of different types of sorting algorithms

## How to use:

```
import soroco

soroco.bubble([5,4,3,2,1])

```

## Available Sorting methods:

* bubble
* selection
* insertion
* heap
* merge
* quick